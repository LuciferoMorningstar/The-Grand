from random import choice

def Game():

#Block 1
#Assignment Block
    def printing_list(k):
        for num,i in enumerate(k):
            print("|".join(i))
            if num<len(k)-1:
                print("---|---|---")
        print()

    a=[[" 1 "," 2 "," 3 "],[" 4 "," 5 "," 6 "],[" 7 "," 8 "," 9 "]]
    printing_list(a)
    error=[]
    lis=[1,2,3,4,5,6,7,8,9]


#Block 2
#Checker Block

    def checker(l2):
        game=0
        for i in range(3):
            if l2[i][0]==l2[i][1]==l2[i][2] or l2[0][i]==l2[1][i]==l2[2][i]:
                return 1
        if l2[0][0]==l2[1][1]==l2[2][2] or l2[0][2]==l2[1][1]==l2[2][0]:
            return 1
        else:
            return 0


#Block 3
#Actual Game Block
    mode=int(input("Enter 1 if you want to play singleplayer and 2 for multiplayer: "))

    i=0
    while i<10:
        if i==9:
            print("Its a Draw........")
            print()
            break
        elif i%2==0:
            print("X\'s Turn")
            move=" X "
        else:
            print("O\'s Turn")
            move=" O "
        if mode==2:
            try:
                    x=int(input("Enter the position number where you want play your move: "))
            except ValueError:
                    print("Error: Invalid number format!")
                    continue
        elif mode==1:
            if move==" X ":
                try:
                    x=int(input("Enter the position number where you want play your move: "))
                except ValueError:
                    print("Error: Invalid number format!")
                    continue
                lis.remove(x)
            else:
                print("Computer\'s move.......")
                x=choice(lis)
                lis.remove(x)
        if 1<=x<=9:
                if x in error:
                    print("Overwriting not allowed")
                    continue
                else:
                    i+=1
                    error.append(x)
                    if 1<=x<=3:
                        a[0][x-1]=move
                    elif 4<=x<=6:
                        a[1][x-4]=move
                    elif 7<=x<=9:
                        a[2][x-7]=move
                    printing_list(a)
                    game=checker(a)
                    if game==1:
                        print(f"{move.strip()} Wins!!!")
                        print()
                        break
        else:
            print("Entered position is out of range.")


#Block 4
#Initiator and Replay Block

while True:
    Game()
    try:
        replay=int(input("Enter 1 if you want to play again else Enter 0: "))
    except ValueError:
        print("Error: Invalid number format!")
        break
    if replay in [0,1]:
        if replay==1:
            continue
        elif replay==0:
            print("Thanks for Playing......")
            break
    else:
        print("The entered option is out of range")
        break

