def leap(year):
    return 1 if year%4==0 and year%100!=0 else (1 if year%400==0 else 0 )
        

def date_validator(date):
    

    date = date.strip()
    if date.count("/")!=2:
        print("Invalid Date Format Entered")
    else:
        temp = date.split("/")
        try:
            temp = [int(i) for i in temp]
        except ValueError:
            print("Invalid Datatype Entered")
                
        if temp[1]>12 or temp[1]<1:
            print("Invalid Month Entered")
                
        else:
            if temp[0]>31 or temp[0]<1 or (temp[0]==31 and temp[1] in [2,4,6,9,11]) or (temp[0]>29 and temp[1]==2):
                print("Invalid Day Entered")
                    
            else:
                if temp[2]>9999 or temp[2]<1000:
                    print("Invalid Year Entered")
                        
                else:
                    k=leap(temp[2])
                    if k==0 and temp[0]==29 and temp[1]==2:
                        print("Invalid Day Entered")
                            
                    else:
                        return date
                           


def spend():
    print("Welcome to the expense recording section!!!")
    print("Please enter the date in the following form DD/MM/YYYY")

    while True:
        while True:
            tareek = input("Enter Date: ")
            Date = date_validator(tareek)
            if Date==None:
                continue
            else:
                break
        
        category = input("Enter the category (like shopping,rent,food,etc): ").title()
        desc = input("Enter description in a few words (like burger,purse,etc): ").title()
        while True:
            try:
                amount = int(input("Enter the amount spent: "))
                break
            except ValueError:
                print("Invalid Datatype Entered")
                continue
        amount = str(amount)

        writer = [Date,category,desc,amount+"\n"]

        with open ("Expenses.txt","a") as file:
            file.write(" ".join(writer))
        
        print("Expense Successfully Recorded")

        while True:
            rewind = input("Enter yes if you want to record another expense else enter no: ")
            if rewind.lower()=="yes":
                break
            elif rewind.lower()=="no":
                print("Thanks for visiting this section")
                return
            else:
                print("Invalid Option Entered")
                continue


    

def view():
    with open ("Expenses.txt","r") as file:
        report = file.readlines()
        report = [report[i].replace("\n","") for i in range(0,len(report))]
        info = [i.split() for i in report]
    
    for i in range(len(info)):
        print(info[i][0]+" "*(17-len(info[i][0]))+info[i][1]+" "*(20-len(info[i][1]))+info[i][2]+" "*(20-len(info[i][2]))+info[i][3])


def search():
    with open ("Expenses.txt","r") as file:
        report = file.readlines()
        reporting = [report[i].replace("\n","") for i in range(0,len(report))]
        info = [i.split() for i in reporting]

    while True:
        DATE = input("Enter the date in DD/MM/YYYY form: ")
        temp = date_validator(DATE)
        if temp==None:
            continue
        else:
            break
    
    flag = False
    for j,i in enumerate(info):
        if DATE==i[0]:
            user_ind = j
            print(reporting[user_ind])
            flag = True
    if not flag:
        print("Not Found")



def summary():
    with open ("Expenses.txt","r") as file:
        report = file.readlines()
        if not report:
            print("No Expenses Recorded yet")
            return
        reporting = [report[i].replace("\n","") for i in range(1,len(report))]
        info = [i.split() for i in reporting]
            
    sumer = 0
    Max,Min = int(info[0][-1]),int(info[0][-1])
    miner,maxer = info[0],info[0]
    for h,i in enumerate(info):
        sumer += int(i[-1])
        if Max<int(i[-1]):
            Max = int(i[-1])
            maxer = i
        if Min>int(i[-1]):
            Min = int(i[-1])
            miner = i

    average = sumer/len(info)
    print("Sum of all Expenses:",sumer)
    print("Average of all Expenses:",average)
    print("The smallest Expense:",*miner)
    print("The largest Expense:",*maxer)


def Expense_Tracker():
    print("Welcome to my Expense Tracker Program")
    print("Choose from the options below")
    print("""1. Add Expense  
2. View All Expenses  
3. Search Expenses by Date  
4. View Summary (Total, Average, Highest, Lowest)  
5. Exit""")
    while True:
        while True:
            try:
                option = int(input("Enter your choice: "))
                break
            except ValueError:
                print("Invalid Datatype Entered")
        if option == 1:
            spend()
        elif option==2:
            view()
        elif option==3:
            search()
        elif option==4:
            summary()
        elif option==5:
            print("Thanks for visiting my program")
            print("GoodBye :)")
            break
        else:
            print("Invalid Option Entered")


Expense_Tracker()