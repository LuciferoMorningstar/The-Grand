import termcolor as tc

from random import choice as cho
def game():
    with open ("help.txt","r") as file:
        words=file.readlines()
        words=[i.replace("\n","") for i in words]
        final=[j for j in words if len(j)>=5]
    ans=cho(final).upper()
    cop=ans
    l=["_"]*len(ans)
    print(" ".join(l))
    guesses=6
    while guesses!=0:
        choice=input("Enter your guess: ").upper()
        lis=[i for i,j in zip(choice,ans) if i==j]
        if choice.strip().isalpha():
            if len(choice)==len(ans):
                if choice==ans:
                    guesses-=1
                    print(tc.colored(choice,"black","on_green"))
                    print("You have guessed the word!!!")
                    print("Guesses used:",6-guesses)
                    break
                else:
                    for i,j,k in zip(choice,ans,[i for i in range(len(ans))]):
                        if i in ans:
                            if i==j:
                                l[k]=tc.colored(i,"black","on_green")
                            elif i!=j and i not in lis and i in cop:
                                l[k]=tc.colored(i,"black","on_yellow")
                            else:
                                l[k]=i
                            
                        else:
                            l[k]=i
                            
                        cop=cop.replace(i,"")
                    guesses-=1
                    cop=ans
                    print("Guesses left:",guesses)
                print(" ".join(l))
            else:
                print("Too many or too less letters were entered.")      
        else:
            print("Only alphabets are allowed.") 
    else:
        print("You could not guess the word.......")
        print("The answer was:",ans)


while True:
    game()
    replay=input("Enter 1 if you want to play again else press 0: ")
    if replay in ["0","1"]:
        if replay=="1":
            continue
        else:
            print("Thanks for playing....")
            break
    else:
        print("Invalid Input")
        break