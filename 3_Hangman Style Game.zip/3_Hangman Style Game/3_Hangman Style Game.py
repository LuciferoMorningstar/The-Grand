#Block 1
#Library Block

from random import choice



#Block 2
#File Insertion Block

with open ("help.txt","r") as file:
    l=file.readlines()



#Block 3
#Game Definition Block

def game():



    #Sub-Block 3.1
    #Assignment Block

    x=choice(l).replace("\n","").upper()
    lis=["_"]*len(x)
    s=set()



    #Sub-Block 3.2
    #Greeting Block
    
    print("Welcome to my Game!!!!")
    print("You need to guess the letters of a random word until all the letters are uncovered.")
    print("You will get 6 lives and for each wrong Choice you will loose one life.")
    print(" ".join(lis))



    #Sub-Block 3.3
    #Game Logic Block

    k=6
    while k>0:
        Choice=input("Enter a character: ").upper().strip()
        if len(Choice)==1:
            if not Choice.isalpha():
                print("Only alphabets are allowed.")
                continue
            if Choice not in s:
                s.add(Choice)
                print(f"Guessed letters: {', '.join(sorted(s))}")
                if Choice in x:
                    for i,j in enumerate(x):
                        if j==Choice:
                            lis[i]=Choice
                    print(" ".join(lis))
                else:
                    print("Wrong guess.")
                    k-=1
                    print(f"Lives remaining: {k}")
                if "_" not in lis:
                    print("You have guessed the word!!!")
                    print(" ".join(lis), f"   Lives: {k}")
                    break
            else:
                print("This letter was already guessed once.....")

        else:
            print("Too many or too less letters were inputted.")
        if k==0:
            print("You lost......")
            print(f"The random word was: {x}")
        


#Block 4
#Initiation and Replay Block

while True:
    game()
    try:
        replay=int(input("Enter 1 if you want to play again else enter 0: "))
    except ValueError:
        print("Invalid Datatype entered.")
    if replay in [0,1]:
        if replay==1:
            continue
        else:
            print("Thanks for Playing!!!")
            break
    else:
        print("Inputted option is out of range.")
        break
