from tkinter import *

lis=[]


root = Tk()
root.geometry("500x200")
root.title("Stack")


value=StringVar(root)



def rem():
    if len(lis) != 0:
        lis.pop(-1)
        value.set("Last Value Removed")
    else:
        value.set("List is Empty")
    return lis

def add():
    k=entry.get()
    lis.append(k)
    value.set("Item Added")
    return lis


def peek():
    if len(lis) != 0:
        value.set(lis[-1])
    else:
        value.set("List is empty")
    


def check():
    if len(lis)!=0:
        value.set("List Not Empty")
    else:
        value.set("List is Empty")
def show():
    value.set(f"{lis}")



value=StringVar(root)
entry=Entry(root,textvariable=value, font=("Arial", 24), justify="right", bd=8, relief="ridge")
entry.pack()


Button(root,text="Push",command=add, width=5, height=2, font=("Arial", 18),bg="lightblue",fg="red").pack(side=LEFT,padx=10)
Button(root,text="Pop",command=rem, width=5, height=2, font=("Arial", 18),bg="lightblue",fg="red").pack(side=LEFT,padx=10)
Button(root,text="Peek",command=peek, width=5, height=2, font=("Arial", 18),bg="lightblue",fg="red").pack(side=RIGHT,padx=10)
Button(root,text="Void?",command=check, width=5, height=2, font=("Arial", 18),bg="lightblue",fg="red").pack(side=RIGHT,padx=10)
Button(root,text="Stack",command=show, width=5, height=2, font=("Arial", 18),bg="lightblue",fg="red").pack(side=RIGHT,padx=10)


root.mainloop()