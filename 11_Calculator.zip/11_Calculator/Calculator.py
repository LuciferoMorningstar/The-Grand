from tkinter import *

cal=Tk()
cal.title("Calculator")
# cal.geometry("400x500")

ans=0
symbol={}
val=StringVar()
def func(inte):
    if val.get()=="Error" or val.get()=="Not Defined":
        val.set(inte)
    else:
        val.set(val.get()+inte)

def func2(inte):
    if val.get() == "":
        return
    elif val.get()[-1] not in ("+","-","*","/"):
        val.set(val.get()+inte)
    else:
        val.set(val.get()[:-1]+inte)

def backspace():
    val.set(val.get()[:-1])

def operate():
    str1=val.get()
    if "^" in str1:
        str1=str1.replace("^","**")

    try:
        ans=eval(str1)
        val.set(ans)
    except ZeroDivisionError:
        val.set("Not Defined")
    except Exception:
        val.set("Error")
    
    

entry = Entry(cal, textvariable=val, font=("Arial", 24), justify="right", bd=8, relief="ridge")
entry.grid(row=0, column=0, columnspan=4, padx=10, pady=15, ipadx=8, ipady=8)


but=Button(cal, text="7", command=lambda:func("7"), width=5, height=2, font=("Arial", 18)).grid(row=2, column=1)
but=Button(cal, text="8", command=lambda:func("8"), width=5, height=2, font=("Arial", 18)).grid(row=2, column=2)
but=Button(cal, text="9", command=lambda:func("9"), width=5, height=2, font=("Arial", 18)).grid(row=2, column=3)
but=Button(cal, text="4", command=lambda:func("4"), width=5, height=2, font=("Arial", 18)).grid(row=3, column=1)
but=Button(cal, text="5", command=lambda:func("5"), width=5, height=2, font=("Arial", 18)).grid(row=3, column=2)
but=Button(cal, text="6", command=lambda:func("6"), width=5, height=2, font=("Arial", 18)).grid(row=3, column=3)
but=Button(cal, text="1", command=lambda:func("1"), width=5, height=2, font=("Arial", 18)).grid(row=4, column=1)
but=Button(cal, text="2", command=lambda:func("2"), width=5, height=2, font=("Arial", 18)).grid(row=4, column=2)
but=Button(cal, text="3", command=lambda:func("3"), width=5, height=2, font=("Arial", 18)).grid(row=4, column=3)
but=Button(cal, text="0", command=lambda:func("0"), width=5, height=2, font=("Arial", 18)).grid(row=5, column=2)
but=Button(cal, text=".", command=lambda:func("."), width=5, height=2, font=("Arial", 18)).grid(row=5, column=1)


but=Button(cal,text="\u232b",command=lambda:backspace(),width=5, height=2, font=("Arial", 18),bg="#00C853", fg="white").grid(row=1,column=3)
but=Button(cal,text="AC",command=lambda:val.set(""),width=5, height=2, font=("Arial", 18),bg="#00C853", fg="white").grid(row=1,column=2)
but=Button(cal,text="=",command=lambda:operate(),width=5, height=2, font=("Arial", 18), bg="#FF5252", fg="white").grid(row=5,column=3)

but=Button(cal,text="+",command=lambda:func2("+"),width=5, height=2, font=("Arial", 18),bg="#FFA000", fg="white").grid(row=2,column=0)
but=Button(cal,text="-",command=lambda:func2("-"),width=5, height=2, font=("Arial", 18),bg="#FFA000", fg="white").grid(row=3,column=0)
but=Button(cal,text="*",command=lambda:func2("*"),width=5, height=2, font=("Arial", 18),bg="#FFA000", fg="white").grid(row=4,column=0)
but=Button(cal,text="/",command=lambda:func2("/"),width=5, height=2, font=("Arial", 18),bg="#FFA000", fg="white").grid(row=5,column=0)
but=Button(cal,text="^",command=lambda:func2("^"),width=5, height=2, font=("Arial", 18),bg="#FFA000", fg="white").grid(row=1,column=0)


for i in range(4):
    cal.columnconfigure(i, weight=1)
for i in range(6):
    cal.rowconfigure(i, weight=1)

a=Label(cal,text="")
a.grid(row=5)
cal.mainloop()
