# Python Challenge: Smart Log Analyzer

def Log_analyser(log):
    main = {}

    for i in log:
        temp = list(map(lambda x: x.strip(),i.split("|")))
        if len(temp) != 4:
            continue
        try:
            temp[-1] = int(temp[-1])
        except ValueError:
            continue
        if temp[-1] < 0:
            continue

        temp[1] = temp[1].upper() 
        temp[2] = temp[2].upper()
        date,name,action,dur = temp

        if date in main:
            if name in main[date]:
                if action in main[date][name]:
                    main[date][name][action] += dur
                else:
                    main[date][name][action] = dur
            else:
                main[date][name] = {action : dur}
        else:
            main[date] = {name : {action : dur}}
    for i,j in main.items():
        for k,l in j.items():
            main[i][k]["TOTAL"] = sum(main[i][k].values())


    return main


logs = [
    "2025-12-01 | Raj | LOGIN | 5",
    "2025-12-01 | Raj | LOGIN | 3",
    "2025-12-01 | Raj | LOGOUT | 4",
    "2025-12-01 | Archit | LOGIN | 2",
    "2025-12-02 | Raj | LOGIN | 6",
    "2025-12-02 | Archit | LOGOUT | 3",
    "2025-12-02 | Saksham | LOGIN | 7",
    "2025-12-02 | Saksham | LOGIN | -2",   
    "2025-12-XX | Raj | LOGIN | 5"          
]

eg = Log_analyser(logs)
for i,j in eg.items():
    print(i,":",j)


