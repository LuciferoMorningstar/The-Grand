# Python Challenge: Smart Log Analyzer

def Log_analyser(log):
    main = {}

    for i in log:
        action = []
        temp = list(map(lambda x: x.strip(),i.split("|")))
        if len(temp) != 4:
            continue
        try:
            temp[-1] = int(temp[-1])
        except ValueError:
            continue
        if temp[-1] < 0:
            continue

        temp[1] = temp[1].upper()
        temp[2] = temp[2].upper()
        action.append(temp[2])
     

        if temp[1] not in main:
            main[temp[1]] = {temp[2]:temp[-1]}
            

        else:
            if temp[2] in main[temp[1]]:
                main[temp[1]][temp[2]] += temp[-1]
                

            else:
                main[temp[1]][temp[2]] = temp[-1]

    for i in main: 
        main[i]["TOTAL"] = sum(main[i].values())

    return main

        




logs = [
    "2025-12-01 | Raj | LOGIN | ",
    "2025-12-01 | Archit | LOGIN | 3",
    "2025-12-01 | Raj | LOGOUT | 2",
    "2025-12-02 | Raj | LOGIN | 4",
    "2025-12-02 | Archit | LOGOUT | 1",
    "2025-12-02 | Saksham | LOGIN | 6"
]
k=Log_analyser(logs)

Log_analyser(logs)
eg = Log_analyser(logs)
if eg == 0:
    print("Invalid Value(s) was Entered.")
else:
    for i,j in eg.items():
        print(i,":",j)


