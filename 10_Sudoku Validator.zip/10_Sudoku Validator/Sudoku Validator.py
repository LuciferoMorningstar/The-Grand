from pprint import pprint

def validator(lis):
    flag = True

    # Creating Vertical list
    ver = []
    for i in range(9):
        temp=[]
        for j in range(9):
            temp.append(lis[j][i])
        ver.append(temp)
    
    x = 0 
    y = 0
    grid = []
    for k in range(1,10):
        temp = []
        for i in range(3):
            for j in range(3):
                temp.append(lis[x+i][y+j])
        grid.append(temp)
        y+=3
        if k%3==0:
            x += 3 
            y = 0



    # Horizontal Checker
    for i in lis:
        for j in range(1,10):
            if j not in i:
                flag = False
                return flag
            
    # Vertical Checker
    for i in ver:
        for j in range(1,10):
            if j not in i:
                flag = False
                return flag
    
    # Grid Checker
    for i in grid:
        for j in range(1,10):
            if j not in i:
                flag = False
                return flag
    return flag
        
# eg_sudoku = [
#     [5,3,4,6,7,8,9,1,2],
#     [6,7,2,1,9,5,3,4,8],
#     [1,9,8,3,4,2,5,6,7],
#     [8,5,9,7,6,1,4,2,3],
#     [4,2,6,8,5,3,7,9,1],
#     [7,1,3,9,2,4,8,5,6],
#     [9,6,1,5,3,7,2,8,4],
#     [2,8,7,4,1,9,6,3,5],
#     [3,4,5,2,8,6,1,7,9]
# ]

sudoku = []
flag = True
for i in range(9):
    x = input(f"Enter all the 9 numbers of the row {i + 1} each seperated by a space: ")
    if x.strip().count(" ")!=8:
        print("Invalid input entered")
        break
    else:
        temp = []
        for j in x.split():
            if j.isdigit():
                temp.append(int(j))
            else:
                print("Invalid Datatype was found")
                flag = False
                break
        else:
            sudoku.append(temp)
    if flag:
        continue
    else:
        break

else:
    pprint(sudoku)

check = validator(sudoku)
if check:
    print("The solution is Valid")
else:
    print("The solution is Invalid")