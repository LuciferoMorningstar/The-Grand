"""
Number Guessing Game:
Develop a game where the computer generates a random number, and the user tries to
guess it. The program provides hints (higher/lower) until the correct number is guessed.
This project utilizes random number generation, loops, and conditional logic.
"""

def guessing_game():
    import random

    computer = random.randint(0, 9)



    print("""Choose 
          1 for Easy Mode [9 Guesses]
          2 for Medium Mode [5 Guesses]
          3 for Hard Mode [3 Guesses]
          """)
    
    mode=input("Enter your choice: ")
    if mode.isdigit():
        if int(mode)==1:
            attempts=9
        elif int(mode)==2:
            attempts=5
        elif int(mode)==3:
            attempts=3
        else:
            print("Invalid Selection of Mode")
            return
    else:
        print("Invalid Datatype Entered")
        return
    
    print(f"You get {attempts} guesses.")
    for i in range(1,attempts+1):
        guess=input("Enter your guess from 0 to 9: ")
            
        if guess.isdigit():
            guess=int(guess)
            if 9>=guess>=0:
                if guess>computer:
                    print("Lower")
                    print(f"Number of Attempts remaining {attempts-i}",end="\n")
                elif guess<computer:
                    print("Higher")
                    print(f"Number of Attempts remaining {attempts-i}",end="\n")
                else:
                    print("Computer chose",computer)
                    print("You guessed it.")
                    break
            else:
                print("Invalid Input, try again")
        else:
            print("You have entered an invalid datatype")
            print(f"Number of Attempts remaining {attempts-i}",end="\n")
                
    else:
        print("Computer chose",computer)
        print("You couldn't guess it.......")
    

            
while True:
    guessing_game()
    replay = input("Choose 1 if you want to play again else choose 0: ")
    if replay == '0':
        print("Thanks for playing!")
        break
    elif replay=="1":
        continue
    else:
        print("Invalid option entered.....")
        break

