import random
def game():
    computer = random.randint(1, 3)
    if computer==1:
        computers="Rock"
    if computer==2:
        computers="Paper"
    if computer==3:
        computers="Scissor"

    print("""Choose one of the three options:
        Rock
        Paper
        Scissor
        """)
    userere=input("Enter your choice: ")
    usererer=userere.capitalize()
    if usererer=="Rock":
        user=1
    elif usererer=="Paper":
        user=2
    elif usererer=="Scissor":
        user=3
    else:
        user=""
        print("Invalid Selection")
    if user:
        print(f"""
        Computer selected {computers}
        User selected {usererer}
        """)

        if computer==user:
            print("It is a draw")
            f=open("Score.txt","a")
            f.write("\n Draw")
            f.close()
        else:
            if computer==1 and user==2:
                print("User Win!",end="\n")
                f=open("Score.txt","a")
                f.write("\n Win")
                f.close()
            elif computer==1 and user==3:
                print("User Lost",end="\n")
                f=open("Score.txt","a")
                f.write("\n Lost")
                f.close()
            elif computer==2 and user==3:
                print("User Win!",end="\n")
                f=open("Score.txt","a")
                f.write("\n Win")
                f.close()
            elif computer==2 and user==1:
                print("User Lost",end="\n")
                f=open("Score.txt","a")
                f.write("\n Lost")
                f.close()
            elif computer==3 and user==1:
                print("User Win!",end="\n")
                f=open("Score.txt","a")
                f.write("\n Win")
                f.close()
            elif computer==3 and user==2:
                print("User Lost",end="\n")
                f=open("Score.txt","a")
                f.write("\n Lost")
                f.close()
            else:
                print("Something went wrong")
    else:
        print("Try Again")
        
# while True:
#     game()
#     replay=int(input("Enter 1 if you want to play again else enter 0: "))
#     if replay==0:
#         print("Thanks for Playing........")
#         break
#     elif replay!=0 and replay!=1:
#         print("Invalid Input")
#         break

with open ("help.txt","r") as f:
    l=f.readlines()
print(l)