# Importing Required Libraries
from random import *
from time import *


# Reading the file for stats and name
with open("Planetsummary.txt","r") as file:
    text1 = file.readline().split()
    text2 = file.readline().split()
    text3 = file.readline().strip()

# List of Events (Normal, Negative and Rare)
normal_events = [
    {
        "name": "Gentle Rain",
        "type": "normal",
        "description": "A calm rainfall nourishes crops and rivers.",
        "effects": {"food": +10, "water": +20}
    },
    {
        "name": "Sunny Day",
        "type": "normal",
        "description": "Perfect weather boosts morale and productivity.",
        "effects": {"happiness": +5}
    },
    {
        "name": "Community Feast",
        "type": "normal",
        "description": "Villagers gather and share food together.",
        "effects": {"food": -5, "happiness": +15}
    },
    {
        "name": "River Discovery",
        "type": "normal",
        "description": "A new water source has been found nearby.",
        "effects": {"water": +25}
    },
    {
        "name": "Morning Market",
        "type": "normal",
        "description": "Trade activity increases local wealth.",
        "effects": {"happiness": +5}
    },
    {
        "name": "Fruitful Harvest",
        "type": "normal",
        "description": "The farms yield an above-average harvest this season.",
        "effects": {"food": +30, "happiness": +10}
    }
]

negative_events = [
    {
        "name": "Drought",
        "type": "negative",
        "description": "The rivers dry up and crops begin to wilt.",
        "effects": {"water": -25, "food": -10}
    },
    {
        "name": "Bandit Attack",
        "type": "negative",
        "description": "Bandits raid the outskirts of your settlement.",
        "effects": {"food": -10, "population": -5}
    },
    {
        "name": "Crop Disease",
        "type": "negative",
        "description": "A blight spreads among the crops.",
        "effects": {"food": -30}
    },
    {
        "name": "Minor Quake",
        "type": "negative",
        "description": "A small earthquake damages some homes.",
        "effects": {"happiness": -10, "population": -3}
    },
    {
        "name": "Wild Animal Attack",
        "type": "negative",
        "description": "Predators threaten nearby villagers.",
        "effects": {"population": -5, "food": -5}
    }
]

rare_events = [
    {
        "name": "Ancient Relic Found",
        "type": "rare",
        "description": "Explorers uncover a relic that inspires everyone.",
        "effects": {"happiness": +25}
    },
    {
        "name": "Golden Rain",
        "type": "rare",
        "description": "Shimmering rain showers down, boosting morale and crops.",
        "effects": {"food": +20, "water": +20, "happiness": +20}
    },
    {
        "name": "Hero Emerges",
        "type": "rare",
        "description": "A brave hero rises among your people.",
        "effects": {"population": +10, "happiness": +30}
    },
    {
        "name": "Blessing of Nature",
        "type": "rare",
        "description": "Everything flourishes in perfect balance for a short while.",
        "effects": {"food": +15, "water": +15, "happiness": +15}
    }
]

# Intro and Stats Overview
stats = {i:int(j) for i,j in zip(text1,text2)}
print("Welcome to your own planet!!!")
print("Try to survive for 30 days.")
if text3=="":
    name = input('Enter the name of your planet: ')
    with open("Planetsummary.txt","a") as file:
        file.write(name)
else:
    name = text3
print(f"Planet {name}")
print("Stats")
print("-"*(25))
for i,j in stats.items():
    if i!="turn":
        print(i.title()," "*(10-len(i)),":"," "*(5),j)

# Starting Game Option centre
counter = 0
while True:
    flag = 0
    print(f"Day - {stats["turn"]}")
    print("Choose an Option")
    print("""1. Grow crops\n2. Build houses\n3. Collect Water\n4. Explore new land\n5. Rest\n6. Exit World""")
    while True:
        try:
            option = int(input("Enter your option: "))
            break
        except ValueError:
            print("Invalid Datatype Entered.")
    
    # Implementing the chosen option
    while True:
        if option == 1:
            stats["food"] += 20
            stats["water"] -= 15
            stats["happiness"] += 5
            break
        
        elif option == 2:
            stats["population"] += 15
            stats["food"] -= 10
            stats["water"] -= 5
            stats["happiness"] += 5
            break
        
        elif option == 3:
            stats["water"] += 25
            stats["food"] -= 5
            break
        
        elif option == 4:
            population = choice([5,-5])
            food = choice([5,-5])
            water = choice([5,-5])
            stats["population"] += population
            stats["food"] += food
            stats["water"] += water
            break
        
        elif option == 5:
            stats["happiness"] += 15
            stats["food"] -= 10
            stats["water"] -= 5
            break

        elif option == 6:
            flag = 1
            break
        
        else:
            print("Invalid Choice Entered")

    # Printing Updated Stats
    for i,j in stats.items():
        if i!="turn":
            print(i.title()," "*(10-len(i)),":"," "*(5),j)
        
    # Checking whether world Collapsed or not
    for i in stats.values():
        if i <= 0:
            print("Your World has Collapsed......")
            flag = 1
            break
        else:
            continue
    
    # Day and action counter
    if option != 6:
        counter += 1
    if counter%5 == 0:
        print("A new day has begun")
        stats["turn"] += 1
        stats["food"] -= 5
        stats["water"] -= 5

    # Event Probability
    luck = randint(1,100)
    if luck >= 1 and luck <= 10:
        lucky = -1
    elif luck > 10 and luck <= 70:
        lucky = 0
    elif luck > 70 and luck <= 95:
        lucky = +1
    else:
        lucky = 5

    # Event Happening
    event = None
    if lucky == -1:
        event = choice(negative_events)
    elif lucky == 1:
        event = choice(normal_events)
    elif lucky == 5:
        event = choice(rare_events)
    else:
        event = None
    if event == None:
        pass
    else:
        print("An Event is taking place.........")
        sleep(3)
        print(event["name"])
        print(event["description"])
        for key, value in event["effects"].items():
            stats[key] += value
            print(f"{key.title()} changed by {value}")
        for i,j in stats.items():
            if i!="turn":
                print(i.title()," "*(10-len(i)),":"," "*(5),j)
    

    # Losing condition check
    for i in stats.values():
        if i <= 0:
            print("Your World has Collapsed......")
            print("Your final stats")
            for i,j in stats.items():
                if i!="turn":
                    print(i.title()," "*(10-len(i)),":"," "*(5),j)
            flag = 1
            break
        else:
            continue
    
    # Writing the new stats in the txt file
    with open("Planetsummary.txt","w") as file:
        updater = {i:str(j) for i,j in stats.items()}
        file.write(" ".join(updater.keys()) + "\n")
        file.write(" ".join(updater.values()) + "\n")
        file.write(name)

    # Outer loop break Condition
    if flag == 1:
        break

    # Win condition check
    if stats["turn"] == 30:
        print("You have successfully survived for 30 days!!!!")
        print("Congrats You Win!!!!")
        print("Final Stats")
        for i,j in stats.items():
            if i!="turn":
                print(i.title()," "*(10-len(i)),":"," "*(5),j)
        break
